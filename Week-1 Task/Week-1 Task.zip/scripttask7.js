// Simple and clean
const workerProfile = "Hi I am good worker and consistent person";


console.log("Worker Message:", workerProfile);